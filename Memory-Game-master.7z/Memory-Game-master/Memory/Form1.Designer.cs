﻿namespace Memory
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.bestandToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.speelOpnieuwToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spelSluitenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.content = new System.Windows.Forms.Panel();
            this.a24 = new System.Windows.Forms.PictureBox();
            this.a23 = new System.Windows.Forms.PictureBox();
            this.a22 = new System.Windows.Forms.PictureBox();
            this.a21 = new System.Windows.Forms.PictureBox();
            this.a20 = new System.Windows.Forms.PictureBox();
            this.a19 = new System.Windows.Forms.PictureBox();
            this.a18 = new System.Windows.Forms.PictureBox();
            this.a17 = new System.Windows.Forms.PictureBox();
            this.a16 = new System.Windows.Forms.PictureBox();
            this.a15 = new System.Windows.Forms.PictureBox();
            this.a14 = new System.Windows.Forms.PictureBox();
            this.a13 = new System.Windows.Forms.PictureBox();
            this.a12 = new System.Windows.Forms.PictureBox();
            this.a11 = new System.Windows.Forms.PictureBox();
            this.a10 = new System.Windows.Forms.PictureBox();
            this.a9 = new System.Windows.Forms.PictureBox();
            this.a8 = new System.Windows.Forms.PictureBox();
            this.a7 = new System.Windows.Forms.PictureBox();
            this.a6 = new System.Windows.Forms.PictureBox();
            this.a5 = new System.Windows.Forms.PictureBox();
            this.a4 = new System.Windows.Forms.PictureBox();
            this.a3 = new System.Windows.Forms.PictureBox();
            this.a2 = new System.Windows.Forms.PictureBox();
            this.a1 = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.content.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.a24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.a1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bestandToolStripMenuItem,
            this.spelSluitenToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(919, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // bestandToolStripMenuItem
            // 
            this.bestandToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.speelOpnieuwToolStripMenuItem});
            this.bestandToolStripMenuItem.Name = "bestandToolStripMenuItem";
            this.bestandToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.bestandToolStripMenuItem.Text = "Bestand";
            // 
            // speelOpnieuwToolStripMenuItem
            // 
            this.speelOpnieuwToolStripMenuItem.Name = "speelOpnieuwToolStripMenuItem";
            this.speelOpnieuwToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.speelOpnieuwToolStripMenuItem.Text = "Speel opnieuw";
            // 
            // spelSluitenToolStripMenuItem
            // 
            this.spelSluitenToolStripMenuItem.Name = "spelSluitenToolStripMenuItem";
            this.spelSluitenToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.spelSluitenToolStripMenuItem.Text = "Sluiten";
            this.spelSluitenToolStripMenuItem.Click += new System.EventHandler(this.spelSluitenToolStripMenuItem_Click);
            // 
            // content
            // 
            this.content.Controls.Add(this.a24);
            this.content.Controls.Add(this.a23);
            this.content.Controls.Add(this.a22);
            this.content.Controls.Add(this.a21);
            this.content.Controls.Add(this.a20);
            this.content.Controls.Add(this.a19);
            this.content.Controls.Add(this.a18);
            this.content.Controls.Add(this.a17);
            this.content.Controls.Add(this.a16);
            this.content.Controls.Add(this.a15);
            this.content.Controls.Add(this.a14);
            this.content.Controls.Add(this.a13);
            this.content.Controls.Add(this.a12);
            this.content.Controls.Add(this.a11);
            this.content.Controls.Add(this.a10);
            this.content.Controls.Add(this.a9);
            this.content.Controls.Add(this.a8);
            this.content.Controls.Add(this.a7);
            this.content.Controls.Add(this.a6);
            this.content.Controls.Add(this.a5);
            this.content.Controls.Add(this.a4);
            this.content.Controls.Add(this.a3);
            this.content.Controls.Add(this.a2);
            this.content.Controls.Add(this.a1);
            this.content.Location = new System.Drawing.Point(13, 28);
            this.content.Name = "content";
            this.content.Size = new System.Drawing.Size(529, 515);
            this.content.TabIndex = 1;
            // 
            // a24
            // 
            this.a24.Location = new System.Drawing.Point(434, 382);
            this.a24.Name = "a24";
            this.a24.Size = new System.Drawing.Size(80, 120);
            this.a24.TabIndex = 23;
            this.a24.TabStop = false;
            this.a24.Click += new System.EventHandler(this.clickImage);
            // 
            // a23
            // 
            this.a23.Location = new System.Drawing.Point(348, 382);
            this.a23.Name = "a23";
            this.a23.Size = new System.Drawing.Size(80, 120);
            this.a23.TabIndex = 22;
            this.a23.TabStop = false;
            this.a23.Click += new System.EventHandler(this.clickImage);
            // 
            // a22
            // 
            this.a22.Location = new System.Drawing.Point(262, 382);
            this.a22.Name = "a22";
            this.a22.Size = new System.Drawing.Size(80, 120);
            this.a22.TabIndex = 21;
            this.a22.TabStop = false;
            this.a22.Click += new System.EventHandler(this.clickImage);
            // 
            // a21
            // 
            this.a21.Location = new System.Drawing.Point(176, 382);
            this.a21.Name = "a21";
            this.a21.Size = new System.Drawing.Size(80, 120);
            this.a21.TabIndex = 20;
            this.a21.TabStop = false;
            this.a21.Click += new System.EventHandler(this.clickImage);
            // 
            // a20
            // 
            this.a20.Location = new System.Drawing.Point(90, 382);
            this.a20.Name = "a20";
            this.a20.Size = new System.Drawing.Size(80, 120);
            this.a20.TabIndex = 19;
            this.a20.TabStop = false;
            this.a20.Click += new System.EventHandler(this.clickImage);
            // 
            // a19
            // 
            this.a19.Location = new System.Drawing.Point(4, 382);
            this.a19.Name = "a19";
            this.a19.Size = new System.Drawing.Size(80, 120);
            this.a19.TabIndex = 18;
            this.a19.TabStop = false;
            this.a19.Click += new System.EventHandler(this.clickImage);
            // 
            // a18
            // 
            this.a18.Location = new System.Drawing.Point(434, 256);
            this.a18.Name = "a18";
            this.a18.Size = new System.Drawing.Size(80, 120);
            this.a18.TabIndex = 17;
            this.a18.TabStop = false;
            this.a18.Click += new System.EventHandler(this.clickImage);
            // 
            // a17
            // 
            this.a17.Location = new System.Drawing.Point(348, 256);
            this.a17.Name = "a17";
            this.a17.Size = new System.Drawing.Size(80, 120);
            this.a17.TabIndex = 16;
            this.a17.TabStop = false;
            this.a17.Click += new System.EventHandler(this.clickImage);
            // 
            // a16
            // 
            this.a16.Location = new System.Drawing.Point(262, 256);
            this.a16.Name = "a16";
            this.a16.Size = new System.Drawing.Size(80, 120);
            this.a16.TabIndex = 15;
            this.a16.TabStop = false;
            this.a16.Click += new System.EventHandler(this.clickImage);
            // 
            // a15
            // 
            this.a15.Location = new System.Drawing.Point(176, 256);
            this.a15.Name = "a15";
            this.a15.Size = new System.Drawing.Size(80, 120);
            this.a15.TabIndex = 14;
            this.a15.TabStop = false;
            this.a15.Click += new System.EventHandler(this.clickImage);
            // 
            // a14
            // 
            this.a14.Location = new System.Drawing.Point(90, 256);
            this.a14.Name = "a14";
            this.a14.Size = new System.Drawing.Size(80, 120);
            this.a14.TabIndex = 13;
            this.a14.TabStop = false;
            this.a14.Click += new System.EventHandler(this.clickImage);
            // 
            // a13
            // 
            this.a13.Location = new System.Drawing.Point(4, 256);
            this.a13.Name = "a13";
            this.a13.Size = new System.Drawing.Size(80, 120);
            this.a13.TabIndex = 12;
            this.a13.TabStop = false;
            this.a13.Click += new System.EventHandler(this.clickImage);
            // 
            // a12
            // 
            this.a12.Location = new System.Drawing.Point(434, 130);
            this.a12.Name = "a12";
            this.a12.Size = new System.Drawing.Size(80, 120);
            this.a12.TabIndex = 11;
            this.a12.TabStop = false;
            this.a12.Click += new System.EventHandler(this.clickImage);
            // 
            // a11
            // 
            this.a11.Location = new System.Drawing.Point(348, 130);
            this.a11.Name = "a11";
            this.a11.Size = new System.Drawing.Size(80, 120);
            this.a11.TabIndex = 10;
            this.a11.TabStop = false;
            this.a11.Click += new System.EventHandler(this.clickImage);
            // 
            // a10
            // 
            this.a10.Location = new System.Drawing.Point(262, 130);
            this.a10.Name = "a10";
            this.a10.Size = new System.Drawing.Size(80, 120);
            this.a10.TabIndex = 9;
            this.a10.TabStop = false;
            this.a10.Click += new System.EventHandler(this.clickImage);
            // 
            // a9
            // 
            this.a9.Location = new System.Drawing.Point(176, 130);
            this.a9.Name = "a9";
            this.a9.Size = new System.Drawing.Size(80, 120);
            this.a9.TabIndex = 8;
            this.a9.TabStop = false;
            this.a9.Click += new System.EventHandler(this.clickImage);
            // 
            // a8
            // 
            this.a8.Location = new System.Drawing.Point(90, 130);
            this.a8.Name = "a8";
            this.a8.Size = new System.Drawing.Size(80, 120);
            this.a8.TabIndex = 7;
            this.a8.TabStop = false;
            this.a8.Click += new System.EventHandler(this.clickImage);
            // 
            // a7
            // 
            this.a7.Location = new System.Drawing.Point(4, 130);
            this.a7.Name = "a7";
            this.a7.Size = new System.Drawing.Size(80, 120);
            this.a7.TabIndex = 6;
            this.a7.TabStop = false;
            this.a7.Click += new System.EventHandler(this.clickImage);
            // 
            // a6
            // 
            this.a6.Location = new System.Drawing.Point(434, 4);
            this.a6.Name = "a6";
            this.a6.Size = new System.Drawing.Size(80, 120);
            this.a6.TabIndex = 5;
            this.a6.TabStop = false;
            this.a6.Click += new System.EventHandler(this.clickImage);
            // 
            // a5
            // 
            this.a5.Location = new System.Drawing.Point(348, 4);
            this.a5.Name = "a5";
            this.a5.Size = new System.Drawing.Size(80, 120);
            this.a5.TabIndex = 4;
            this.a5.TabStop = false;
            this.a5.Click += new System.EventHandler(this.clickImage);
            // 
            // a4
            // 
            this.a4.Location = new System.Drawing.Point(262, 4);
            this.a4.Name = "a4";
            this.a4.Size = new System.Drawing.Size(80, 120);
            this.a4.TabIndex = 3;
            this.a4.TabStop = false;
            this.a4.Click += new System.EventHandler(this.clickImage);
            // 
            // a3
            // 
            this.a3.Location = new System.Drawing.Point(176, 4);
            this.a3.Name = "a3";
            this.a3.Size = new System.Drawing.Size(80, 120);
            this.a3.TabIndex = 2;
            this.a3.TabStop = false;
            this.a3.Click += new System.EventHandler(this.clickImage);
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(90, 4);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(80, 120);
            this.a2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.a2.TabIndex = 1;
            this.a2.TabStop = false;
            this.a2.Click += new System.EventHandler(this.clickImage);
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(4, 4);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(80, 120);
            this.a1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.a1.TabIndex = 0;
            this.a1.TabStop = false;
            this.a1.Click += new System.EventHandler(this.clickImage);
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(569, 32);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(93, 41);
            this.btnStart.TabIndex = 2;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.startGame);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(569, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "00:60";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(919, 555);
            this.ControlBox = false;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.content);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Memory";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.content.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.a24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.a1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem bestandToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem speelOpnieuwToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spelSluitenToolStripMenuItem;
        private System.Windows.Forms.Panel content;
        private System.Windows.Forms.PictureBox a24;
        private System.Windows.Forms.PictureBox a23;
        private System.Windows.Forms.PictureBox a22;
        private System.Windows.Forms.PictureBox a21;
        private System.Windows.Forms.PictureBox a20;
        private System.Windows.Forms.PictureBox a19;
        private System.Windows.Forms.PictureBox a18;
        private System.Windows.Forms.PictureBox a17;
        private System.Windows.Forms.PictureBox a16;
        private System.Windows.Forms.PictureBox a15;
        private System.Windows.Forms.PictureBox a14;
        private System.Windows.Forms.PictureBox a13;
        private System.Windows.Forms.PictureBox a12;
        private System.Windows.Forms.PictureBox a11;
        private System.Windows.Forms.PictureBox a10;
        private System.Windows.Forms.PictureBox a9;
        private System.Windows.Forms.PictureBox a8;
        private System.Windows.Forms.PictureBox a7;
        private System.Windows.Forms.PictureBox a6;
        private System.Windows.Forms.PictureBox a5;
        private System.Windows.Forms.PictureBox a4;
        private System.Windows.Forms.PictureBox a3;
        private System.Windows.Forms.PictureBox a2;
        private System.Windows.Forms.PictureBox a1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label label1;
    }
}

